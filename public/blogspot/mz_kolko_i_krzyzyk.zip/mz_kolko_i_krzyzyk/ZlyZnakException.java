package mz_kolko_i_krzyzyk;

public class ZlyZnakException extends Exception {
	public ZlyZnakException(String s){
		super(s);
	}
}
