package mz_kolko_i_krzyzyk;

public class Znak {
	private String znak;
	
	public void ustaw(String _znak){
		znak = _znak;
	}
	
	public String rysuj(){
		return znak;
	}
}
